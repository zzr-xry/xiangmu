# 功能一：障碍物智能检测（前向）

基于策划书「前向障碍与相对接近趋势」口径实现的最小可行程序。运行平台：ESP32-S3 DevKitC-1，Arduino 框架（PlatformIO）。

## 1. 接线

| 器件 | 接 ESP32-S3 |
|---|---|
| VL53L1X（前）SDA/SCL | GPIO8 / GPIO9 |
| VL53L1X（前）XSHUT | GPIO10 |
| VL53L1X（下视）XSHUT | GPIO11 |
| MPU6050 SDA/SCL | GPIO8 / GPIO9（共用总线） |
| 有源蜂鸣器 | GPIO12，经 NPN/MOS 驱动 |
| 振动马达 | GPIO13，经 MOS 驱动 |
| WS2812B 灯环 8 灯 | GPIO47（DIN） |
| 求助键（预留） | GPIO14，内部上拉 |

> 两路 ToF 出厂地址同为 `0x29`，程序通过 XSHUT 分时拉起后分别改为 `0x30`、`0x31`，不要在同一时刻同时使能两路。

## 2. 编译与烧录

```bash
# 安装 PlatformIO（若未安装）
pip3 install platformio
cd /workspace/forward_obstacle
pio run -t upload
pio device monitor        # 115200 波特
```

也可用 Arduino IDE：安装库 `STM32duino VL53L1X`、`Adafruit MPU6050`、`Adafruit NeoPixel`、`Adafruit Unified Sensor`，把 `src/` 下所有 `.cpp/.h` 放同一目录，主文件用 `main.cpp` 改名 `.ino`。

## 3. 输出与日志

- 一级提示：黄灯常亮 + 短鸣 100ms / 1s
- 二级警示：红灯闪烁 + 连续鸣叫 + 振动
- 传感异常：蓝灯 + 三短鸣（连续 3 帧无有效读数触发）

串口 CSV 每行字段：`seq,t_us,front_raw_mm,d_filt_m,v_mps,ttc_s,valid,gz,turning,idle,state`，与策划书表12「单次台架试验记录」字段对齐，可直接用于后期分组回放与指标统计。

## 4. 判据要点（对应策划书原文）

1. 中值滤波 5 帧抑制单帧跳变；
2. 300ms 窗口最小二乘估计相对接近速度，避免帧间差分放大噪声；
3. `TTC = 距离 / 接近速度`，仅当速度 > 0.15 m/s 时计算；
4. 转弯（|gz|>0.7 rad/s 持续 300ms）与静止（v<0.15 m/s）分别抑制误报；
5. 分级：一级 `d≤1.25m 且 TTC≤2.0s 持续 60ms`，二级 `d≤0.65m 或 TTC≤1.0s`；
6. 解除需 `d≥1.40m 持续 500ms`（滞回），同级重复提醒冷却 1.5s。

所有参数集中在 `src/config.h` 的 V0 版本，预实验后统一修改并重新烧录，保证演示与独立验证使用同一参数版本。

## 5. 验收自测

| 步骤 | 操作 | 期望 |
|---|---|---|
| 静态标定 | 卷尺量 0.3 / 0.6 / 1.2 / 1.5 / 2.0 m，白门板 | 读数偏差与量程记录 |
| 距离触发 | 手持匀速靠近门板，观察 `d_filt` 与 state | 1.25m 附近进入 L1，0.65m 进入 L2 |
| 误报对照 | 贴墙静止 60s、平行通过、原地快速转身 | 不进入 L1/L2 |
| 提前量 | 0.8 m/s 推车接近，记录首次 L1 的距离 | ≥1.2 m，不满足则对外降级表述 |
| 失效处理 | 用黑布遮挡传感器 | 连续 3 帧无效进入 ERR，蓝灯三短鸣 |

## 6. 与后续功能的衔接

- 功能二「异常状态监测」：本程序已采集 MPU6050 的 `gx/gy/gz` 并写入日志，`judge.cpp` 中的 `r.turning` 是姿态应用的入口，可扩展倾斜角判据。
- 功能三「一键紧急求助」：`output.cpp` 已把 GPIO14 设为输入上拉，后续加按键扫描与本地反馈即可，无需改动现有判据。
