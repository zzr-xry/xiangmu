#pragma once
#include "config.h"

void output_init();
// 非阻塞刷新声光振动，传入当前状态
void output_update(AlgState s);
