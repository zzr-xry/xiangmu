#include "sensors.h"
#include "config.h"
#include <Wire.h>
#include <VL53L1X.h>
#include <Adafruit_MPU6050.h>
#include <Adafruit_Sensor.h>
#include <esp_timer.h>

static VL53L1X frontToF;
static VL53L1X downToF;
static Adafruit_MPU6050 mpu;
static bool mpuReady = false;
static uint32_t seqCounter = 0;

// 分时改址：两个 VL53L1X 出厂地址都是 0x29，必须用 XSHUT 逐个拉起后改址
static bool init_one(VL53L1X &dev, uint8_t xshutPin, uint8_t newAddr) {
  pinMode(xshutPin, OUTPUT);
  digitalWrite(xshutPin, LOW);
  delay(5);
  digitalWrite(xshutPin, HIGH);
  delay(10);                       // 等待传感器上电启动
  if (!dev.begin()) return false;  // 在 0x29 上通信
  dev.setAddress(newAddr);         // 改成本工程地址
  return true;
}

static void config_one(VL53L1X &dev) {
  dev.setDistanceMode(VL53L1X::Long);
  dev.setMeasurementTimingBudget(TIMING_BUDGET_US);
  dev.startContinuous(0);          // 连续模式，间隔 0 = 按 timing budget 最快
}

bool sensors_init() {
  Wire.begin(PIN_SDA, PIN_SCL);
  Wire.setClock(400000);

  bool ok = true;
  ok &= init_one(frontToF, PIN_XSHUT_F, ADDR_FRONT);
  ok &= init_one(downToF,  PIN_XSHUT_D, ADDR_DOWN);
  if (!ok) return false;

  config_one(frontToF);
  config_one(downToF);

  mpuReady = mpu.begin();
  if (mpuReady) {
    mpu.setAccelerometerRange(MPU6050_RANGE_2_G);
    mpu.setGyroRange(MPU6050_RANGE_250_DEG);
    mpu.setFilterBandwidth(MPU6050_BAND_21_HZ);
  }
  return true;  // mpu 失败不致命：前向功能可退化为无转弯抑制
}

bool sensors_read(Measurement &m) {
  // 以前向 ToF 的 dataReady 为节拍；未就绪时短暂让出 CPU
  unsigned long t0 = millis();
  while (!frontToF.dataReady()) {
    if (millis() - t0 > 100) return false;  // 超时，交给上层记录失效
    delay(1);
  }

  m.seq = ++seqCounter;
  m.t_us = esp_timer_get_time();

  uint16_t rf = frontToF.read();                 // 单位 mm
  m.d_front = rf / 1000.0f;
  m.front_valid = (rf > (uint16_t)(MIN_RANGE_M * 1000) &&
                   rf < (uint16_t)(MAX_RANGE_M * 1000));

  if (downToF.dataReady()) {
    uint16_t rd = downToF.read();
    m.d_down = rd / 1000.0f;
    m.down_valid = (rd > 20 && rd < 2000);
  } else {
    m.d_down = 0; m.down_valid = false;
  }

  if (mpuReady) {
    sensors_event_t a, g, temp;
    mpu.getEvent(&a, &g, &temp);
    m.gx = g.gyro.x; m.gy = g.gyro.y; m.gz = g.gyro.z;
    m.imu_valid = true;
  } else {
    m.gx = m.gy = m.gz = 0; m.imu_valid = false;
  }
  return true;
}
