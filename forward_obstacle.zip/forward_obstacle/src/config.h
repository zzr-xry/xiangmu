#pragma once
#include <Arduino.h>

// ---------- 引脚（ESP32-S3-DevKitC-1，按你板子丝印核对）----------
#define PIN_SDA        8
#define PIN_SCL        9
#define PIN_XSHUT_F    10   // 前向 ToF 的 XSHUT
#define PIN_XSHUT_D    11   // 下视 ToF 的 XSHUT（本功能只记录，不参与判据）
#define PIN_BUZZER     12   // 有源蜂鸣器，经 NPN/MOS 驱动
#define PIN_MOTOR      13   // 振动马达，经 MOS 驱动
#define PIN_LED        47   // WS2812B 灯环（48 多为板载 RGB，故外接收 47）
#define PIN_BUTTON     14   // 求助键（功能3预留，本版不使用）

// ---------- 两路 ToF 的 I2C 地址（XSHUT 分时改址）----------
#define ADDR_FRONT     0x30
#define ADDR_DOWN      0x31

// ---------- 采样与缓冲 ----------
#define TIMING_BUDGET_US  50000UL   // ToF 测量时间预算 50ms → 约 20Hz
#define RING_LEN          40        // 环形缓冲：2s @20Hz
#define MEDIAN_N          5         // 中值滤波窗口（有效帧）
#define REGRESS_MS        300       // 速度估计回归窗口

// ---------- 前向判据参数 V0（初值，预实验后冻结）----------
#define D_L1_M          1.25f    // 一级提示距离上限（m）
#define D_L2_M          0.65f    // 二级警示距离（近距独立路径）
#define D_REL_M         1.40f    // 解除距离（滞回，> D_L1）
#define V_MIN_MPS       0.15f    // 判定“正在接近”的最小速度
#define V_IDLE_MPS      0.05f    // 低于此速视为静止/贴墙
#define TTC_L1_S        2.0f     // 一级 TTC 阈值
#define TTC_L2_S        1.0f     // 二级 TTC 阈值
#define HOLD_L1_MS      60       // 一级持续帧时间
#define HOLD_L2_MS      40       // 二级持续帧时间
#define REL_HOLD_MS     500      // 解除需持续稳定时间
#define ALERT_COOLDOWN_MS 1500    // 同级重复提醒冷却
#define TURN_RATE_RPS   0.70f    // 转弯角速度阈值 rad/s（约40°/s）
#define TURN_HOLD_MS    300      // 转弯判定持续时间
#define INVALID_FRAMES  3        // 连续无效帧 → 传感异常状态

// ---------- 有效量程 ----------
#define MIN_RANGE_M     0.05f
#define MAX_RANGE_M     4.00f

// ---------- 版本标识（写入日志）----------
#define FW_VERSION      "0.1.0"
#define PARAM_SET       "V0-20261119"
#define JUDGE_GROUP     "C"      // A 固定阈值 / B 姿态补偿 / C 状态判据

// ---------- 状态定义 ----------
enum AlgState : uint8_t {
  ST_IDLE = 0,   // 常态
  ST_L1   = 1,   // 一级提示
  ST_L2   = 2,   // 二级警示
  ST_ERR  = 3    // 传感异常
};

inline const char* stateName(AlgState s) {
  switch (s) {
    case ST_IDLE: return "IDLE";
    case ST_L1:   return "L1";
    case ST_L2:   return "L2";
    case ST_ERR:  return "ERR";
    default:      return "?";
  }
}
