#include "judge.h"
#include <math.h>

struct Sample { int64_t t_us; float d; };
static Sample ring[RING_LEN];
static int ringHead = 0, ringCount = 0;

static AlgState state = ST_IDLE;
static int invalidStreak = 0;
static uint32_t l1Since = 0, l2Since = 0, relSince = 0;
static uint32_t lastL1Exit = 0;
static int64_t prevT = 0;
static uint32_t turnAccum = 0;

void judge_init() {
  ringHead = ringCount = 0;
  state = ST_IDLE; invalidStreak = 0;
  l1Since = l2Since = relSince = 0;
  lastL1Exit = 0; prevT = 0; turnAccum = 0;
}

static void push(const Measurement &m) {
  ring[ringHead] = { m.t_us, m.d_front };
  ringHead = (ringHead + 1) % RING_LEN;
  if (ringCount < RING_LEN) ringCount++;
}

// 最近 MEDIAN_N 个有效样本的中值
static float medianFiltered() {
  float buf[MEDIAN_N];
  int n = 0;
  for (int i = 1; i <= ringCount && n < MEDIAN_N; i++) {
    int idx = (ringHead - i + RING_LEN) % RING_LEN;
    buf[n++] = ring[idx].d;
  }
  for (int i = 0; i < n; i++)
    for (int j = i + 1; j < n; j++)
      if (buf[j] < buf[i]) { float t = buf[i]; buf[i] = buf[j]; buf[j] = t; }
  if (n == 0) return 0;
  return (n % 2) ? buf[n / 2] : (buf[n / 2 - 1] + buf[n / 2]) / 2.0f;
}

// 以 REGRESS_MS 窗口做最小二乘，斜率取负 = 接近速度（正值）
static float estimateSpeed(int64_t now) {
  double sx = 0, sy = 0, sxx = 0, sxy = 0;
  int n = 0; int64_t tmin = 1e18, tmax = -1;
  for (int i = 0; i < ringCount; i++) {
    int idx = (ringHead - 1 - i + RING_LEN) % RING_LEN;
    int64_t t = ring[idx].t_us;
    if (now - t > (int64_t)REGRESS_MS * 1000) break;
    double x = t / 1e6; double y = ring[idx].d;
    sx += x; sy += y; sxx += x * x; sxy += x * y; n++;
    if (t < tmin) tmin = t;
    if (t > tmax) tmax = t;
  }
  if (n < 4 || (tmax - tmin) < 100000) return 0;   // 窗口内样本不足，不信任速度
  double den = n * sxx - sx * sx;
  if (den <= 1e-9) return 0;
  double slope = (n * sxy - sx * sy) / den;         // d 对 t 的斜率
  float v = (float)(-slope);                        // 接近为正
  if (v < 0) v = 0;
  return v;
}

JudgeResult judge_update(const Measurement &m) {
  JudgeResult r{state, 0, 0, 999, false, false};
  uint32_t now = millis();

  // 转弯判定：角速度持续超限
  if (m.imu_valid) {
    if (prevT != 0) {
      uint32_t dt = (uint32_t)((m.t_us - prevT) / 1000);
      if (dt > 100) dt = 100;
      if (fabs(m.gz) > TURN_RATE_RPS) turnAccum += dt; else turnAccum = 0;
    }
    prevT = m.t_us;
  }
  r.turning = (turnAccum >= TURN_HOLD_MS);

  if (!m.front_valid) {
    invalidStreak++;
    if (invalidStreak >= INVALID_FRAMES) {
      state = ST_ERR;
      l1Since = l2Since = relSince = 0;
    }
    r.state = state;
    return r;
  }
  invalidStreak = 0;
  push(m);

  float d = medianFiltered();
  float v = estimateSpeed(m.t_us);
  float ttc = (v > V_MIN_MPS) ? (d / v) : 999.0f;
  if (ttc > 999) ttc = 999;
  bool idle = (fabs(v) < V_MIN_MPS);

  r.d_filt = d; r.v = v; r.ttc = ttc; r.idle = idle;

  // 各条件的“连续满足时长”
  bool cL1 = (d <= D_L1_M) && (v >= V_MIN_MPS) && (ttc <= TTC_L1_S) && !r.turning && !idle;
  bool cL2 = (d <= D_L2_M) || (ttc <= TTC_L2_S);
  bool cRel = (d >= D_REL_M);

  if (cL1) { if (!l1Since) l1Since = now; } else l1Since = 0;
  if (cL2) { if (!l2Since) l2Since = now; } else l2Since = 0;
  if (cRel) { if (!relSince) relSince = now; } else relSince = 0;

  bool l1Ready = l1Since && (now - l1Since >= HOLD_L1_MS);
  bool l2Ready = l2Since && (now - l2Since >= HOLD_L2_MS);
  bool relReady = relSince && (now - relSince >= REL_HOLD_MS);
  bool cooled = (now - lastL1Exit >= ALERT_COOLDOWN_MS);

  switch (state) {
    case ST_ERR:
      state = ST_IDLE;   // 数据恢复后先回常态，避免直接报警
      break;
    case ST_IDLE:
      if (l2Ready) state = ST_L2;
      else if (l1Ready && cooled) state = ST_L1;
      break;
    case ST_L1:
      if (l2Ready) state = ST_L2;
      else if (relReady) { state = ST_IDLE; lastL1Exit = now; }
      break;
    case ST_L2:
      if (relReady) { state = ST_IDLE; lastL1Exit = now; }
      break;
  }
  r.state = state;
  return r;
}
