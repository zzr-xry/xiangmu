#pragma once
#include "measurement.h"
#include "judge.h"

void logger_header();
void logger_row(const Measurement &m, const JudgeResult &r);
