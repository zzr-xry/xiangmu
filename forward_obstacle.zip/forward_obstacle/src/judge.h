#pragma once
#include "measurement.h"
#include "config.h"

struct JudgeResult {
  AlgState state;
  float d_filt;   // 中值滤波后的距离 m
  float v;        // 相对接近速度 m/s（正 = 接近）
  float ttc;      // 预计碰撞时间 s，无穷大用 999 表示
  bool  turning;  // 转弯抑制生效
  bool  idle;     // 静止抑制生效
};

void judge_init();
// 必须在 sensors_read 成功后调用，传入同一帧数据
JudgeResult judge_update(const Measurement &m);
