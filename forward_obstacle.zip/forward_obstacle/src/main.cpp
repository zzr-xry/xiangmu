#include <Arduino.h>
#include "config.h"
#include "sensors.h"
#include "judge.h"
#include "output.h"
#include "logger.h"

void setup() {
  Serial.begin(115200);
  delay(200);
  output_init();
  if (!sensors_init()) {
    // 硬件初始化失败：蓝灯常亮提示，仍打印日志头便于排查
    Serial.println(F("# SENSOR_INIT_FAIL"));
  }
  judge_init();
  logger_header();
}

void loop() {
  Measurement m;
  if (!sensors_read(m)) return;   // 未就绪或超时，本帧跳过

  JudgeResult r = judge_update(m);
  output_update(r.state);
  logger_row(m, r);
}
