#pragma once
#include <Arduino.h>

// 一帧同步采样数据（前向功能主要用 front_*，其余为同帧留档）
struct Measurement {
  uint32_t seq;
  int64_t  t_us;        // esp_timer 微秒时间戳
  float    d_front;     // 前向距离 m
  bool     front_valid; // 前向读数是否有效
  float    d_down;      // 下视距离 m（本功能只记录）
  bool     down_valid;
  float    gx, gy, gz;  // 角速度 rad/s
  bool     imu_valid;
};
