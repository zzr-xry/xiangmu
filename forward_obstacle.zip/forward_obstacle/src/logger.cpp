#include "logger.h"

void logger_header() {
  Serial.println(F("# fw=" FW_VERSION " param=" PARAM_SET " group=" JUDGE_GROUP));
  Serial.println(F("# seq,t_us,front_raw_mm,d_filt_m,v_mps,ttc_s,valid,gz,turning,idle,state"));
}

void logger_row(const Measurement &m, const JudgeResult &r) {
  // 字段顺序与表12“单次台架试验记录”对齐，便于后期回放
  Serial.print(m.seq);           Serial.print(',');
  Serial.print(m.t_us);          Serial.print(',');
  Serial.print((uint16_t)(m.d_front * 1000)); Serial.print(',');
  Serial.print(r.d_filt, 3);     Serial.print(',');
  Serial.print(r.v, 3);          Serial.print(',');
  Serial.print(r.ttc, 2);        Serial.print(',');
  Serial.print(m.front_valid ? 1 : 0); Serial.print(',');
  Serial.print(m.gz, 3);         Serial.print(',');
  Serial.print(r.turning ? 1 : 0); Serial.print(',');
  Serial.print(r.idle ? 1 : 0);  Serial.print(',');
  Serial.println(stateName(r.state));
}
