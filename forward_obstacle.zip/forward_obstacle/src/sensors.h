#pragma once
#include "measurement.h"

bool sensors_init();
// 阻塞等待下一帧，20Hz 左右；成功返回 true
bool sensors_read(Measurement &m);
