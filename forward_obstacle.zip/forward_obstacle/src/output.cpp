#include "output.h"
#include <Adafruit_NeoPixel.h>

static Adafruit_NeoPixel ring(8, PIN_LED, NEO_GRB + NEO_KHZ800);
static uint32_t tBuzzer = 0, tBlink = 0;
static bool blinkOn = false;

void output_init() {
  pinMode(PIN_BUZZER, OUTPUT);
  pinMode(PIN_MOTOR, OUTPUT);
  digitalWrite(PIN_BUZZER, LOW);
  digitalWrite(PIN_MOTOR, LOW);
  pinMode(PIN_BUTTON, INPUT_PULLUP);   // 功能3预留
  ring.begin();
  ring.show();
}

void output_update(AlgState s) {
  uint32_t now = millis();
  bool buzz = false, vibrate = false;
  uint32_t color = 0;

  switch (s) {
    case ST_IDLE:
      break;   // 常态安静，全部关闭
    case ST_L1: {
      // 短鸣 100ms，每 1000ms 一次；黄灯常亮
      if (now - tBuzzer >= 1000) tBuzzer = now;
      buzz = (now - tBuzzer < 100);
      color = ring.Color(180, 130, 0);
      break;
    }
    case ST_L2:
      // 连续鸣叫 + 红灯闪烁 + 振动
      buzz = true;
      vibrate = true;
      if (now - tBlink >= 250) { tBlink = now; blinkOn = !blinkOn; }
      color = blinkOn ? ring.Color(255, 0, 0) : ring.Color(20, 0, 0);
      break;
    case ST_ERR:
      // 传感异常：三短鸣节律 + 蓝灯
      { uint32_t ph = now % 1200; buzz = (ph < 100) || (ph > 200 && ph < 300) || (ph > 400 && ph < 500); }
      color = ring.Color(0, 80, 200);
      break;
  }

  digitalWrite(PIN_BUZZER, buzz ? HIGH : LOW);
  digitalWrite(PIN_MOTOR, vibrate ? HIGH : LOW);
  for (int i = 0; i < ring.numPixels(); i++) ring.setPixelColor(i, color);
  ring.show();
}
